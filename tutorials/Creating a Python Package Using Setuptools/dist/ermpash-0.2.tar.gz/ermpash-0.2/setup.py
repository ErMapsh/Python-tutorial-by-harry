# using this file u can , generate create file 

from setuptools import setup
setup(name = "ermpash",
    version = "0.2",
    description = "this is a description", 
    long_description = "this is a very very long description", 
    author = "Mahesh", 
    packages = ['ermapsh'], 
    install_requires = [])




# python setup.py sdist bdist_wheel 