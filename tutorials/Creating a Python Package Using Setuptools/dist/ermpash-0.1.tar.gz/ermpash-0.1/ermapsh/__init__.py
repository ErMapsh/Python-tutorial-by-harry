# here is my code (package)

def acchafuc(num):
    print("This is a function")
    return num