# here is my code (package)
class Achha:
    def __init__(self):
        print("constructer ban gaya")

    def acchafuc(self, num):
        print("This is a function")
        return num